                 Thank you for choosing Valius.
    Divine is to thank for a lot of the epic ideas put into this base!
             These are the people to give thanks to

                            Credits:
                  Vencillio team - 50% for base
        Divine/Trebble - 44% main Project Valius developer
       Riley - 5% for some bug/dupe fixes + some other stuff
      Andy - Website/Bug fixes in-game

        Current Developer(s): Divine [02/10/16]-[??/??/??]


             Last updated: [13/12/16] Tuesday 12:06AM